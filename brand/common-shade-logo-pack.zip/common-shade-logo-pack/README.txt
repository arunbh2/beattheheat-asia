Common Shade logo pack
======================

The current Common Shade logo files, from https://beattheheat.asia/brand/

Symbol, for light backgrounds
  The canopy and two posts, as in the site header. For avatars, favicons and small spaces on white or cream.
  Files: common-shade-symbol-light-bg.svg (SVG, 26 x 20, transparent background); common-shade-symbol-light-bg.png (PNG, 1040 x 800, transparent background)
Symbol, for dark backgrounds
  The same mark with cream posts, as on the dark scenes of the site’s films. For dark slides and dark photographs with calm areas.
  Files: common-shade-symbol-dark-bg.svg (SVG, 26 x 20, transparent background); common-shade-symbol-dark-bg.png (PNG, 1040 x 800, transparent background)
App icon
  The mark on its dark rounded tile, as in the browser tab. For profile pictures and app-style tiles.
  Files: common-shade-app-icon.svg (SVG, 32 x 32); common-shade-app-icon.png (PNG, 512 x 512)
Logo with name, for light backgrounds
  The mark and COMMON SHADE in Anton, as in the site header. For documents, slides and partner pages on white or cream.
  Files: common-shade-logo-light-bg.png (PNG, 1085 x 190, transparent background)
Logo with name, for dark backgrounds
  The mark and name in cream, as on the films’ dark scenes. For dark slides and video end cards.
  Files: common-shade-logo-dark-bg.png (PNG, 1085 x 190, transparent background)

Colours
  Common Shade orange #F26430: The canopy in every version of the logo.
  Ink #16202B: The posts and the name on light backgrounds, and the app icon’s tile.
  Cream #F6E7D7: The posts and the name on dark backgrounds.

Using the logo
  - Use the files on this page, as they are, rather than copying the logo from a screenshot.
  - Keep the logo’s proportions: scale it evenly, without stretching or squashing.
  - Do not crop, recolour, outline, rotate or add effects to the logo.
  - Choose the version that stays legible: the light-background files on white or cream, the dark-background files on dark colours.
  - Do not use the logo in a way that suggests Common Shade endorses, funds or partners with an organisation, product or event, unless that has been agreed.
  - When you show a film or an image, credit Common Shade and link to beattheheat.asia.

Rights
  No licence for the Common Shade name and logo has been published, and the site’s licence file lists names, logos and trademarks among what CC BY 4.0 does not cover. Use the logo to refer or link to Common Shade.
  These are practical notes, not formal brand guidelines. No minimum size, clear space or other formal rule has been set.

Questions: https://beattheheat.asia/join/
